"""
Script de nettoyage et migration PrankGuard.
À exécuter UNE SEULE FOIS sur ta machine pour :
  1. Nettoyer main (photos trackées, fichiers inutiles)
  2. Créer la branche v2-migration
  3. Installer les nouveaux modules src/

Usage :
  cd C:\Users\lucas\Desktop\CoursEpitech\prankguard
  python migrate.py
"""
import os
import subprocess
import shutil
import sys


PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))


def run(cmd, description=""):
    """Exécute une commande et affiche le résultat."""
    print(f"\n{'='*60}")
    print(f"  {description}")
    print(f"  > {cmd}")
    print(f"{'='*60}")
    result = subprocess.run(cmd, shell=True, cwd=PROJECT_ROOT, capture_output=True, text=True)
    if result.stdout.strip():
        print(result.stdout.strip())
    if result.returncode != 0 and result.stderr.strip():
        print(f"  [WARN] {result.stderr.strip()}")
    return result.returncode == 0


def main():
    print("\n" + "="*60)
    print("  PrankGuard — Script de migration v18 → src/")
    print("="*60)

    # Vérifier qu'on est dans le bon dossier
    if not os.path.exists(os.path.join(PROJECT_ROOT, "prankguard.py")):
        print("[ERREUR] prankguard.py introuvable ! Lance ce script depuis la racine du projet.")
        sys.exit(1)

    # Vérifier qu'on est sur main
    result = subprocess.run("git branch --show-current", shell=True, cwd=PROJECT_ROOT,
                          capture_output=True, text=True)
    current_branch = result.stdout.strip()
    print(f"\n  Branche actuelle : {current_branch}")

    if current_branch != "main":
        print(f"  [INFO] Passage sur main...")
        run("git checkout main", "Checkout main")

    # ── ÉTAPE 1 : Nettoyer main ──────────────────────────────────────

    print("\n" + "="*60)
    print("  ÉTAPE 1 — Nettoyage de main")
    print("="*60)

    # Retirer les photos du tracking git (elles restent sur disque)
    run("git rm --cached data/owner_faces/*.jpg 2>nul", "Retirer les .jpg du tracking git")
    run("git rm --cached data/owner_faces/*.png 2>nul", "Retirer les .png du tracking git")

    # Supprimer les fichiers inutiles
    files_to_remove = [
        "legacy/prankguard.py",      # Doublon exact de prankguard.py
    ]
    for f in files_to_remove:
        path = os.path.join(PROJECT_ROOT, f)
        if os.path.exists(path):
            os.remove(path)
            run(f"git rm --cached \"{f}\" 2>nul", f"Supprimer {f}")
            print(f"  [OK] Supprimé : {f}")

    # Garder legacy/prankguard_fix.txt comme archive
    # Garder prankguard.py à la racine comme archive v18

    # ── ÉTAPE 2 : Copier les nouveaux fichiers ───────────────────────

    print("\n" + "="*60)
    print("  ÉTAPE 2 — Copie des fichiers corrigés")
    print("="*60)

    # Copier .gitignore, requirements.txt, .bat
    dist_dir = os.path.join(PROJECT_ROOT, "_migration_files")
    if os.path.exists(dist_dir):
        for fname in [".gitignore", "requirements.txt", "run.bat", "setup.bat"]:
            src = os.path.join(dist_dir, fname)
            dst = os.path.join(PROJECT_ROOT, fname)
            if os.path.exists(src):
                shutil.copy2(src, dst)
                print(f"  [OK] Copié : {fname}")

        # Copier src/ (les nouveaux modules)
        src_src = os.path.join(dist_dir, "src")
        src_dst = os.path.join(PROJECT_ROOT, "src")

        if os.path.exists(src_src):
            # Supprimer l'ancien src/ s'il existe
            if os.path.exists(src_dst):
                shutil.rmtree(src_dst)
                print("  [OK] Ancien src/ supprimé")

            shutil.copytree(src_src, src_dst)
            print("  [OK] Nouveau src/ copié (11 modules)")
    else:
        print(f"  [ERREUR] Dossier _migration_files/ introuvable !")
        print(f"  Décompresse le zip dans le dossier du projet d'abord.")
        sys.exit(1)

    # ── ÉTAPE 3 : Commit sur main ────────────────────────────────────

    print("\n" + "="*60)
    print("  ÉTAPE 3 — Commit du nettoyage")
    print("="*60)

    run("git add -A", "git add -A")
    run('git commit -m "feat: migration v18 vers src/ modulaire avec 10 FIX"',
        "Commit")

    # ── ÉTAPE 4 : Résumé ─────────────────────────────────────────────

    print("\n" + "="*60)
    print("  MIGRATION TERMINÉE !")
    print("="*60)
    print()
    print("  Structure finale :")
    print("  ├── prankguard.py          ← Archive v18 (ne pas toucher)")
    print("  ├── legacy/prankguard_fix.txt")
    print("  ├── src/")
    print("  │   ├── main.py            ← NOUVEAU point d'entrée")
    print("  │   ├── config.py")
    print("  │   ├── logger.py")
    print("  │   ├── enrollment.py")
    print("  │   ├── face_analyzer.py")
    print("  │   ├── state_machine.py")
    print("  │   ├── devices/")
    print("  │   │   ├── watcher.py")
    print("  │   │   ├── poller.py")
    print("  │   │   ├── blocker.py")
    print("  │   │   └── notification.py")
    print("  │   ├── security/")
    print("  │   │   └── locker.py")
    print("  │   └── gui/")
    print("  │       └── app.py")
    print("  ├── data/owner_faces/      ← Tes photos (gitignored)")
    print("  ├── run.bat                ← python -m src.main")
    print("  └── requirements.txt       ← face_recognition/dlib")
    print()
    print("  Prochaines étapes :")
    print("    1. git push origin main")
    print("    2. Activer le venv : .\\venv312\\Scripts\\activate")
    print("    3. Lancer : python -m src.main")
    print()


if __name__ == "__main__":
    main()
