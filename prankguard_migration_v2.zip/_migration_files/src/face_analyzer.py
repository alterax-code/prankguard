"""
Analyse faciale avec optimisation frame skip.
FIX 6 — Capture à 30fps, analyse 1 frame sur N, affiche tous les frames
         avec les rectangles du dernier résultat.
"""
import cv2
import face_recognition
import numpy as np
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class FaceResult:
    """Résultat d'analyse pour un visage détecté."""
    location: Tuple[int, int, int, int]  # (top, right, bottom, left)
    is_owner: bool
    distance: float
    face_size: float      # Taille relative du visage (0-1)
    center_offset: float  # Décalage par rapport au centre (0-1)
    is_looking: bool      # Centré + assez grand = regarde l'écran


class FaceAnalyzer:
    """
    Wrapper autour de face_recognition avec frame skip.
    Analyse 1 frame sur N, garde le dernier résultat pour l'affichage.
    """

    def __init__(
        self,
        owner_encodings: list,
        tolerance: float = 0.45,
        min_face_size: float = 0.20,
        center_threshold: float = 0.35,
        analyze_every_n: int = 3
    ):
        self.owner_encodings = owner_encodings
        self.tolerance = tolerance
        self.min_face_size = min_face_size
        self.center_threshold = center_threshold
        self.analyze_every_n = analyze_every_n

        self._frame_count = 0
        self._last_results: List[FaceResult] = []

    @property
    def last_results(self) -> List[FaceResult]:
        """Dernier résultat d'analyse (pour l'affichage continu)."""
        return self._last_results

    def process_frame(self, frame: np.ndarray) -> Optional[List[FaceResult]]:
        """
        Traite un frame. Retourne les résultats si c'est un frame d'analyse,
        None sinon (utiliser last_results pour l'affichage).
        """
        self._frame_count += 1

        if self._frame_count % self.analyze_every_n != 0:
            return None  # Pas un frame d'analyse

        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        locs = face_recognition.face_locations(rgb)
        results = []

        if locs:
            encs = face_recognition.face_encodings(rgb, locs)
            for loc, enc in zip(locs, encs):
                t, r, b, l = loc
                dist = min(face_recognition.face_distance(self.owner_encodings, enc))
                is_own = dist <= self.tolerance
                sz = (b - t) / h
                off = abs((l + r) / 2 - w / 2) / (w / 2)
                looking = sz >= self.min_face_size and off <= self.center_threshold

                results.append(FaceResult(
                    location=loc,
                    is_owner=is_own,
                    distance=dist,
                    face_size=sz,
                    center_offset=off,
                    is_looking=looking,
                ))

        self._last_results = results
        return results

    def draw_on_frame(self, frame: np.ndarray) -> np.ndarray:
        """Dessine les rectangles et labels sur le frame (résultats en cache)."""
        for r in self._last_results:
            t, right, b, l = r.location

            if r.is_owner:
                col = (0, 255, 0)
                lbl = "OWNER"
            elif r.is_looking:
                col = (0, 0, 255)  # BGR rouge
                lbl = "THREAT"
            else:
                col = (0, 165, 255)  # BGR orange
                lbl = "PASSING"

            cv2.rectangle(frame, (l, t), (right, b), col, 2)
            cv2.putText(
                frame, f"{lbl} {r.distance:.2f}",
                (l, t - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, col, 2
            )

        return frame

    def get_situation(self) -> dict:
        """
        Résumé de la situation courante basé sur le dernier résultat.
        Retourne un dict avec : owner, threat, passing, info
        """
        owner = any(r.is_owner for r in self._last_results)
        threat = any(not r.is_owner and r.is_looking for r in self._last_results)
        passing = any(not r.is_owner and not r.is_looking for r in self._last_results)

        # Info texte pour la GUI
        if self._last_results:
            r = self._last_results[0]
            info = f"Sz:{r.face_size:.0%} D:{r.distance:.2f}"
        else:
            info = "--"

        return {
            "owner": owner,
            "threat": threat,
            "passing": passing,
            "info": info,
            "face_count": len(self._last_results),
        }
